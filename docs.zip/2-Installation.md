# Installation

## From package

```bash
dnf install helloworld-rust-binding
```

## From sources

Install the Rust compiler plus AFB/json-c development headers, then build with Cargo:

```bash
git clone https://github.com/redpesk-samples/helloworld-rust-binding.git
cd helloworld-rust-binding
cargo build --release --package helloworld-rust-binding
ln -sfn libhelloworld_rust_binding.so target/release/helloworld-rust-binding.so
```
