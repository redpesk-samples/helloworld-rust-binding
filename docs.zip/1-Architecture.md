# Helloworld Rust service

## Architecture

This project is the Rust equivalent of `helloworld-binding` and implements the same AFB V4 API.

The `helloworld` API exposes three verbs:

- `hello`: converts the first request parameter to an AFB string and returns `Hello <value>!`;
- `sum`: validates one JSON array of signed integers and returns its `i64` sum;
- `info`: returns the static API metadata from `src/info_verb.json`.

The API also creates the `verb_called` event. Each client/session is automatically subscribed on its first `hello` or `sum` request. The event payload is the called verb name.

