# Usage

Start the binding:

```bash
afb-binder -vvv -b ./target/release/helloworld-rust-binding.so
```

Then call the API from another terminal:

```bash
afb-client -H localhost:1234/api helloworld hello
afb-client -H localhost:1234/api helloworld hello Bob
afb-client -H localhost:1234/api helloworld sum '[1,2,3,10]'
afb-client -H localhost:1234/api helloworld info
```

`hello` and `sum` also emit `helloworld/verb_called` after automatically subscribing the current client/session.
